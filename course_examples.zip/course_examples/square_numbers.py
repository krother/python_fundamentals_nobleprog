
# write a program that prints 
# square numbers
# (1, 4, 9, 16, ... 81, 100)

for x in range(1, 11):
    square = pow(x, 2)
    print(square)


x = 1
while x <= 10:
    print(x ** 2)
    x += 1
    
