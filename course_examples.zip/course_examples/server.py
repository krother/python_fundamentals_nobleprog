from flask import Flask, render_template
import pandas as pd

app = Flask(__name__)

@app.route("/animals")
def animals():
    df = pd.read_csv("animals.csv")
    table = "<table>"
    for name, legs in zip(df['name'], df['legs']):
        table += f"<tr><td>{name}</td><td>{legs}</td></tr> \n"
    table += "</table>"
    return table



if __name__ == "__main__":
    app.run()