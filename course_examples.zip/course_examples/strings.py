
# F9 - copies a line into the console and executes it
s = 'my fat cat\n'

s.startswith('cat')

s.startswith('my')

t = s.replace('c', 'r')

s.find('fat')
s.find('cat')

s[3]
s[2]    # indexing
s[3:6]  # slicing
s[-2]

words = s.split()  # separates words by whitespace

s.upper()
s.strip()

# play button or F5 executes entire program
# only output from print() is shown

print(s.startswith('cat'))


# see the length of a string
len(s)
len(words)
# builtin function: function_name(parameter)
# ==> you need 20 of them

# methods: variable.function_method()
# specific for a data type






