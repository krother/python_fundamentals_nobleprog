
import requests


url = "https://en.wikipedia.org/wiki/Romania"

page = requests.get(url)

print(page.status_code)
print(page.text[:200])

s = page.text
c = s.count('Romania')
print(c)
