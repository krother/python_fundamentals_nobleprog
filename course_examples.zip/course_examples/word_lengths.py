
# print each word with its number of characters
text = "my cat ate a tasty fish"

words = text.split()

for w in words:
    # print(w, "has", len(w), "characters")
    print(f"{w:10} has {len(w):5} characters")

