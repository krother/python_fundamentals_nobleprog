# an English/Romanian dictionary
d = {
     'fox': 'vulpe',
     'dog': 'câine'
     }

# key : value
d['cat'] = 'pisica'
d['feline'] = 'pisica'

d['cat'] = 'Katze'


d['cat']  # search: super fast

d['pisica']  # we can only look up keys

d.get('dog')
result = d.get("pisica")
d.get("pisica", "unknown")

len(d)

d.values()

d.keys()

print("she said: 'welcome to Berlin'")
