
import numpy as np      # numpy fast numerical calculations
from PIL import Image   # pillow image manipulation

RED = (255, 0, 0)
GREEN = (0, 255, 0)
PURPLE = (128, 0, 128)
WHITE = (255, 255, 255)
YELLOW = (255, 255, 0)

# 400 x 400 x 3 numbers between 0..255
# 400 x 400 pixels, 3 color channels: red, green, blue
a = np.zeros((400, 400, 3), dtype=np.uint8)

# [row_start:row_end, col_start:col_end]
a[50:100, 50:100] = RED

a[100:200, 300:] = GREEN
a[300:, :] = PURPLE

for x in range(0, 400, 20):
    a[x: x+10, :20] = WHITE

im = Image.fromarray(a)
im.save("image.png")
im

# im.show()