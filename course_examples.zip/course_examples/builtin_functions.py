"""
min            max            abs
range          sum            round
open           enumerate      zip
"""

# pairwise iteration of two lists
fruits = ['apple','banana','orange', 'melon']
prices = [0.55, 0.75, 0.80, 1.23]

for fruit, price in zip(fruits, prices):
    print(fruit, price)

# pairwise iteration over characters
dict(zip(fruits, prices))

# pairwise iteration over characters
list(zip("HELLO", "WORLD"))

# min and max
min(3,5,7,8,-1)

data = [3, 10, 12, 7]
min(data), max(data)

max(fruits)

# sum
sum(data)

# abs
abs(-12.25)

# round
round(-12.25, 2)

# range
list(range(4, 17, 2))
#list(range(start=4, stop=17, step=2))

# same without range
i = 4
while i < 17:
    print(i)
    i += 2

#i = 4
#while i >= 17 and i <= 20:
#     i += 3


print(list(range(100)))

for num in range(100):
    print(num)

for i in range(1, 20):
    if i % 3 == 0:  # % is modulo: remainder of division
        print(i)

    
# enumerate
list(enumerate(fruits))

for i, name in enumerate(fruits, 1):
    print(i, name)


# type conversion
str(prices)
int(1.234)
list("hello")
bool(fruits)  # True if not empty



