"""
Kingdom Simulator
"""
# here we import our own function
# from a .py file in the same folder
from report import print_resources


def build(selected, resources):
    if selected == 'lumber mills':
        resources['lumber mills'] += 1
        
    elif selected == 'quarries' and resources['wood'] >= 2:
        resources['quarries'] += 1  # modify a variable
        resources['wood'] -= 2
        
    elif selected == 'mage towers' and resources['stone'] >= 10 and resources['wood'] >= 10:
        resources['mage towers'] += 1
        resources['wood'] -= 10
        resources['stone'] -= 10
        
    elif selected == 'castle' and resources['wood'] >= 100 and resources['stone'] >= 100 and resources['mana'] >= 100:
        resources['castle'] = True
        
    else:
        print('not enough resources!\n')
    return resources


def produce(resources):
    resources['wood'] += resources['lumber mills']
    resources['stone'] += resources['quarries']
    resources['mana'] += resources['mage towers']


def simulate(resources, building_name):
    """main function of the game"""
    resources = build(building_name, resources)
    produce(resources)
    return resources

    

if __name__ == "__main__":
    # initialize resources
    resources = {
        'wood': 0,
        'stone': 0,
        'mana': 0,
        
        'lumber mill': 0,
        'quarry': 0,
        "mage tower": 0,
        'castle': False,
    }
    months = 1
    
    while not resources['castle']:  # repeat the following block of code
        print_resources(months, resources)
    
        for counter, name in enumerate(buildings, 1):  # repeat the next 2 lines 
            print(f"[{counter}] {name}")
        
        selected = input()    
        simulate(resources, selected)      
    
    print(f"\nYou built the enchanted castle in {months} months.")
