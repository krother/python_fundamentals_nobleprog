
import os


def test_listdir():
    """checks if the directory contains the correct file size."""
    # remove output file if it exists
    if os.path.exists("output.txt"):
        os.remove("output.txt")

    # run the ls -l command
    # write the output into a file
    #os.chdir("myfolder/")
    os.system("ls -l > output.txt")
    
    # read the output file
    with open("output.txt", "r") as f:
        text = f.read()

    # check the contents
    assert "drwxrwxr" in text
    assert "1347" in text


def _test_fake_solver():
    os.system("runmysolver.sh")
    
    results = read_results()
    
    assert result['score'] > 97.0 and result['score'] < 99.0
