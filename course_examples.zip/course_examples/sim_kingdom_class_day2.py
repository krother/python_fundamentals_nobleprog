"""
Kingdom Simulator
"""
# here we import our own function
# from a .py file in the same folder
from report import print_resources


class SimKingdom:
    
    def __init__(self):
        """constructor method. Called automaticall when you create an object from the class"""
        # attribute : a variable inside a class
        # method : a function inside a class
        
        # we define what attributes the class should contain
        self.resources = {
            'wood': 0,
            'stone': 0,
            'mana': 0,
                    
            'lumber mills': 0,
            'quarries': 0,
            "mage towers": 0,
            'castle': False,
        }
        self.month = 1

    def build(self, selected):
        if selected == 'lumber mills':
            self.resources['lumber mills'] += 1
            
        elif selected == 'quarries' and self.resources['wood'] >= 2:
            self.resources['quarries'] += 1  # modify a variable
            self.resources['wood'] -= 2
            
        elif selected == 'mage towers' and self.resources['stone'] >= 10 and self.resources['wood'] >= 10:
            self.resources['mage towers'] += 1
            self.resources['wood'] -= 10
            self.resources['stone'] -= 10
            
        elif selected == 'castle' and self.resources['wood'] >= 100 and self.resources['stone'] >= 100 and self.resources['mana'] >= 100:
            self.resources['castle'] = True          
        else:
            print('not enough resources!\n')
    
    def produce(self):
        self.resources['wood'] += self.resources['lumber mills']
        self.resources['stone'] += self.resources['quarries']
        self.resources['mana'] += self.resources['mage towers']
    
    def simulate(self, building_name):
        """main function of the game"""
        self.build(building_name)
        self.produce()
    


if __name__ == "__main__":
    # initialize resources
    sim = SimKingdom()
    while not sim.resources['castle']:  # repeat the following block of code
        print_resources(sim)
    
        for counter, name in enumerate(buildings, 1):  # repeat the next 2 lines 
            print(f"[{counter}] {name}")
        
        selected = input()    
        sim.simulate(selected)      
    
    print(f"\nYou built the enchanted castle in {months} months.")
