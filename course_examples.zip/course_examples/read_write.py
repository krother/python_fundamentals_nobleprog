
# read / write text files

text = 'I know some Python already'
filename = '/home/nobleprog/Desktop/output.txt'

# write to a new file
with open(filename, 'w') as f:
    f.write(text)

# read the file
with open(filename, 'r') as f:
    result = f.read()

print(result)
