"""
- how to install packages?
  in ../site-packages/ 

      pip install <name>
  
  check what is there:
      
      pip freeze

- where to find code examples?

  pypi.org
  https://github.com/krother/python3_package_examples


example: read some data, manipuate a field, write the data back

Pattern: input -> processing -> output

"""

# step 1: XML
# input: read the data from text to lists
data = []
for line in open("animals.txt"):
    columns = line.split(",")
    data.append(columns)

# processing: -
replacement = {
    "carnivore": "meat",
    "herbivore": "plants"
   }


# output: write the data to an XML file
import xml.etree.ElementTree as ET

doc = ET.Element('animal_list')
 
data_entries = ET.SubElement(doc, 'entries')

for name, num_legs, food, skin in data:
    animal = ET.SubElement(data_entries, 'animal')
    animal.set("name", name)
    
    if food == "carnivore":
        food = "meat"
    animal.set("food", food)
    animal.text = skin

    legs = ET.SubElement(animal, 'legs')
    legs.set("number", num_legs)
    # TODO: check whether XML can be made pretty

b_xml = ET.tostring(doc)
with open("animals.xml", "wb") as f:
    f.write(b_xml)


"""
data = read_xml("before.xml")
clean(data)
write_xml(data, "after.xml")
"""


# 2. HTML (using an HTML library to read the XML file)
from bs4 import BeautifulSoup

print("====== READ XML FILE =======")
xml_string = open("animals.xml").read()  # ==> str
tree = BeautifulSoup(xml_string, "lxml") # special object (tree of tags)

for animal in tree.find_all('animal'):
    name = animal.get('name')
    food = animal.get("food")
    print(f"{name:20}  {food:20}")



# 3. SQL
from sqlalchemy import create_engine

# connection string - specifies which db server/db/username we are using
db = create_engine("sqlite:///example.db")
# "postgres://kristian:1234@mydbserver.com:5432/animaldb"
# engine = create_engine("oracle+cx_oracle://scott:tiger@hostname:port/?service_name=myservice&encoding=UTF-8&nencoding=UTF-8")

db.execute('''
CREATE TABLE IF NOT EXISTS animals (
    id INTEGER,
    name VARCHAR(32),
    legs INTEGER,
    food VARCHAR(16)
);''')

db.execute('DELETE FROM animals')
           
for i, (name, num_legs, food, skin) in enumerate(data, 1):
    db.execute('INSERT INTO animals VALUES (?,?,?,?)',
               i, name, num_legs, food
               )


# read data
print("===== READ SQL =====")
result = db.execute('SELECT * FROM animals')
for entry in result:
    print(entry)


# not too great: we mix SQL code and Python code
# alternatives:
# - put the SQL code into .sql files, read them in the .py program
# - define a ORM class with SQLAlchemy
#   (a special way to write classses)
#   very clean but a bit more work
# class Animal:
#    name: VarcharColumn()
#    legs: IntegerColumn()
    

# 4. tables (Excel + CSV)
import pandas as pd
from matplotlib import pyplot as plt

db = create_engine("sqlite:///example.db")
df = pd.read_sql("SELECT * FROM animals", db)

# edit the legs column
df["legs"] = df["legs"].replace("2 or 4", 4)
df["legs"] = df["legs"].astype(int)
df["legs"].value_counts().plot.bar()
plt.savefig("plot.png")  # save the plot
print(df)

df.to_csv("animals.csv")
df.to_excel("animals.xlsx")


# 5. writing docx
from docx import Document

print("====== write word document =====")

table = pd.read_excel("animals.xlsx")

d = Document()

d.add_heading('Animals:')
for name in table["name"]:
    d.add_paragraph(name)
    
d.save('animals.docx')


# 6. pattern matching in text
#    Regular Expressions
import re

text = open("animals.csv").read()
print(text)

pattern = r"d\w+"  # all words that start with d
print(re.findall(pattern, text, re.IGNORECASE))

pattern = r"[0-9]+"  # all numbers
print(re.sub(pattern, "NUMBER", text, re.IGNORECASE))

# replacement in an XML file
print("==== replace in XML =====")
ani = open("animals.xml").read()
pattern = r"\d+"
print(re.sub(pattern, "NUMBER", ani, re.IGNORECASE))


# 7. user interface (via web server)
