"""
Automated Test:
    a program checking whether the kingdom simulator 
    is working correctly
    
Run from a terminal with:
    
    pytest
    
pytest finds all files named test_something
and runs all functions named test_xxx in them.
"""
from sim_kingdom import SimKingdom


def test_produce():
    """simulate a single round of the game"""
    sim = SimKingdom()
    sim.simulate(building_name='lumber mills') 
    assert sim.resources['wood'] == 1
    # check if the condition is True or False
    #  True : the test is successful
    #  False : the test fails
    
    # when the test ends, Python automacially cleans sim from the memory
    # (Garbage Collection)


def test_produce_many_lumber_mills():
    """simulate a single round of the game"""
    sim = SimKingdom()
    sim.resources['wood'] = 10
    sim.resources['lumber mills'] = 9
    sim.simulate(building_name='lumber mills') 
    assert sim.resources['wood'] == 20
