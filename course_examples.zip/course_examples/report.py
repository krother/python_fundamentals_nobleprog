

def print_resources(months, resources, lumber_mills, quarries, mage_towers):
    print(f"""
    Month {months:2}:
    =========
    you have:""")
    
    for key in resources.keys():
        print(f"{resources[key]:7}  {key}")

    print(f"""
    {lumber_mills:4} lumber mills
    {quarries:4} quarries
    {mage_towers:4} mage towers
    
    Select what you want to build (and press <ENTER>):
    """)
