"""
Kingdom Simulator
"""

def print_resources(months, resources, resource_names, lumber_mills, quarries, mage_towers):
    print(f"""
    Month {months:2}:
    =========
    you have:""")
    for num in range(0, 3):
        print(f"{resources[num]:4}  {resource_names[num]}")


    print(f"""
{lumber_mills:4} lumber mills
{quarries:4} quarries
{mage_towers:4} mage towers

Select what you want to build (and press <ENTER>):
""")



# initialize resources
resource_names = ['wood', 'stone', 'mana']
resources = [0, 0, 0]

lumber_mills, quarries, mage_towers = 0, 0, 0  # tuple

castle_built = False   # boolean: True or False
months = 1

buildings = ['lumber mill', 'quarry', 'mage tower', 'castle']  # list

while not castle_built:  # repeat the following block of code

    print_resources(months, resources, resource_names, lumber_mills, quarries, mage_towers)

    # 2. print the menu
    counter = 1
    for name in buildings:  # repeat the next 2 lines 
        print(f"[{counter}] {name}")
        counter += 1

    # 3. decide what to build
    selected = input()

    # 4. build a new building if possible
    # TODO: move into a function
    wood, stone, mana = resources
    if selected == '1':
        lumber_mills += 1
    elif selected == '2' and wood >= 2:
        quarries += 1  # modify a variable
        wood -= 2
    elif selected == '3' and stone >= 10 and wood >= 10:
        mage_towers += 1
        wood -= 10
        stone -= 10
    elif selected == '4' and wood >= 100 and stone >= 100 and mana >= 100:
        castle_built = True
    else:
        print('not enough resources!\n')

    # 5. produce goods
    wood += lumber_mills
    stone += quarries
    mana += mage_towers
    
    resources = [wood, stone, mana]

print(f"\nYou built the enchanted castle in {months} months.")
