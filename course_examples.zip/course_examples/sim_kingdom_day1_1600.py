"""
Kingdom Simulator
"""

def print_resources(months, resources, lumber_mills, quarries, mage_towers):
    print(f"""
    Month {months:2}:
    =========
    you have:""")
    
    for key in resources.keys():
        print(f"{resources[key]:7}  {key}")

    print(f"""
    {lumber_mills:4} lumber mills
    {quarries:4} quarries
    {mage_towers:4} mage towers
    
    Select what you want to build (and press <ENTER>):
    """)


def build(selected, resources, lumber_mills, quarries, mage_towers):
    castle_built = False
    if selected == '1':
        lumber_mills += 1
    elif selected == '2' and resources['wood'] >= 2:
        quarries += 1  # modify a variable
        resources['wood'] -= 2
    elif selected == '3' and resources['stone'] >= 10 and resources['wood'] >= 10:
        mage_towers += 1
        resources['wood'] -= 10
        resources['stone'] -= 10
    elif selected == '4' and resources['wood'] >= 100 and resources['stone'] >= 100 and resources['mana'] >= 100:
        castle_built = True
    else:
        print('not enough resources!\n')
    return resources, lumber_mills, quarries, mage_towers, castle_built


def produce(resources, lumber_mills, quarries, mage_towers):
    resources['wood'] += lumber_mills
    resources['stone'] += quarries
    resources['mana'] += mage_towers



# initialize resources
resources = {
    'wood': 0,
    'stone': 0,
    'mana': 0
}

#TODO: you could create another dict for this one
buildings = ['lumber mill', 'quarry', 'mage tower', 'castle']  # list
lumber_mills, quarries, mage_towers = 0, 0, 0  # tuple

castle_built = False   # boolean: True or False
months = 1


while not castle_built:  # repeat the following block of code

    print_resources(months, resources, lumber_mills, quarries, mage_towers)

    # 2. print the menu
    for counter, name in enumerate(buildings, 1):  # repeat the next 2 lines 
        print(f"[{counter}] {name}")
    
    # 3. decide what to build
    selected = input()

    # 4. build a new building if possible
    resources, lumber_mills, quarries, mage_towers, castle_built = build(
        selected, resources, lumber_mills, quarries, mage_towers
        )
    
    # 5. produce goods
    produce(resources, lumber_mills, quarries, mage_towers)
    

print(f"\nYou built the enchanted castle in {months} months.")
