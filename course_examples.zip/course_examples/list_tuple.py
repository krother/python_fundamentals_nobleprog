
# tuple with strings
buildings = ('lumber mill', 'quarry', 'mage tower', 'castle')
buildings[1:]
# tuple is immutable
# does not work: append, pop, sort

# packing and unpacking
a = 1, 2, 3

b, c, d = 4, 5, 6

b, *c, d = buildings


# list with integers
numbers = [3, 1, 0]

numbers.append(5)  # new element added at (the end
numbers.pop()      # removes from the end
numbers.sort(reverse=True)

# also: index, slice, iterate with for
