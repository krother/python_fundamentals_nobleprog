
# how does Python know where to find files to import?

# ==> it looks in the import paths
import sys

sys.path.append("/home/nobleprog/Desktop")
# alternative: put the folder name into the PYTHONPATH
#              environment variable

print(sys.path)

# now we can import a module from our own place
import hello_world

# call our own function that is somewhere else
hello_world.hello()
