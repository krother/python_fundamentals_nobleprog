
from PIL import Image   # pillow image manipulation
import numpy as np

path = "/home/nobleprog/Desktop/"
# on Windows "C:\\Users\\NobleProg\\Desktop\\"
filename = "castle.png"

im = Image.open(path + filename)
a = np.array(im)

# (red, green, blue, alpha) 0..255
# alpha 0 : fully transparent
# alpha 255 : full opacity
a[:, :50] = (0, 0, 255, 255)  # with transparency

im = Image.fromarray(a)
im
